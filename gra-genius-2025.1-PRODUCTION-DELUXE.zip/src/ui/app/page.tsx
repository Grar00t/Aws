import Link from 'next/link';
export default function Home() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">مرحبًا بك في GrA × Genius</h1>
      <p className="opacity-80">منصة ذكاء سيادي على بنية Bluvalt داخل المملكة.</p>
      <Link className="inline-block rounded-lg bg-primary px-4 py-2" href="/dashboard">الانتقال للوحة التحكم</Link>
    </div>
  );
}
