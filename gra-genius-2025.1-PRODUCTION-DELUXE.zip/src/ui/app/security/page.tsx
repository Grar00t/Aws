export default function Security() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">الأمن والامتثال</h1>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="card p-4">
          <div className="text-sm opacity-80">Data Localization (CCC-2-2024 §1.1)</div>
          <div className="mt-2 text-green-400 font-semibold">PASS</div>
          <div className="text-xs opacity-70 mt-2">Bluvalt فقط + NetworkPolicy deny egress</div>
        </div>
        <div className="card p-4">
          <div className="text-sm opacity-80">Encryption at Rest</div>
          <div className="mt-2 text-green-400 font-semibold">PASS</div>
          <div className="text-xs opacity-70 mt-2">Cinder/LUKS + pgcrypto</div>
        </div>
      </div>
    </div>
  );
}
