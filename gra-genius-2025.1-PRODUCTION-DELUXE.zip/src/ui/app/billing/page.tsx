export default function Billing() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">الفوترة والاستهلاك</h1>
      <div className="card p-4">
        <p className="opacity-80">سيتم دمجها مع خدمة node-billing لاحقًا، وتعرض الاستخدام والباقة الحالية.</p>
      </div>
    </div>
  );
}
