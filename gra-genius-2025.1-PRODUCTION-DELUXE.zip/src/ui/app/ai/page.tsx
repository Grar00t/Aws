'use client';
import { useEffect, useState } from 'react';
import { getModels } from '@/lib/api';

export default function AIPage() {
  const [models, setModels] = useState<string[]>([]);
  useEffect(()=>{ getModels().then(setModels).catch(()=>setModels([])); },[]);
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">نماذج الذكاء</h1>
      <div className="card p-4">
        <div className="opacity-80 mb-2">النماذج المتاحة من vLLM:</div>
        <ul className="list-disc list-inside">
          {models.length ? models.map(m => <li key={m}>{m}</li>) : <li>لا توجد نماذج أو الخدمة غير متاحة</li>}
        </ul>
      </div>
    </div>
  );
}
