import { MetricCard } from './components/MetricCard';
import { KPIChart } from './components/KPIChart';
import { AIPerformanceGraph } from './components/AIPerformanceGraph';
import { UsageTrends } from './components/UsageTrends';
import { TenantSelector } from './components/TenantSelector';

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">لوحة التحكم</h1>
        <TenantSelector />
      </div>

      <section className="grid md:grid-cols-3 gap-4">
        <MetricCard label="SLA" value="99.95%" trend="+0.01%" />
        <MetricCard label="p95 API (ms)" value="180" trend="-12%" />
        <MetricCard label="p95 AI (s)" value="2.6" trend="-8%" />
      </section>

      <section className="grid lg:grid-cols-2 gap-4">
        <KPIChart />
        <AIPerformanceGraph />
      </section>

      <section>
        <UsageTrends />
      </section>
    </div>
  );
}
