'use client';
import { useState, useEffect } from 'react';

export function LangToggle() {
  const [rtl, setRtl] = useState(true);
  useEffect(()=>{
    const html = document.documentElement;
    html.setAttribute('dir', rtl ? 'rtl' : 'ltr');
    html.setAttribute('lang', rtl ? 'ar' : 'en');
  }, [rtl]);
  return (
    <button onClick={()=>setRtl(!rtl)} className="rounded-lg border px-3 py-1">
      {rtl ? 'EN' : 'AR'}
    </button>
  );
}
