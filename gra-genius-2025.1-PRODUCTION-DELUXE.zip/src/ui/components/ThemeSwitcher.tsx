'use client';
import { useEffect, useState } from 'react';

export function ThemeSwitcher() {
  const [dark, setDark] = useState(true);
  useEffect(()=>{
    document.body.classList.toggle('theme-dark', dark);
    document.body.classList.toggle('theme-light', !dark);
  }, [dark]);
  return (
    <button onClick={()=>setDark(!dark)} className="rounded-lg border px-3 py-1">
      {dark ? 'الوضع الفاتح' : 'الوضع الداكن'}
    </button>
  );
}
