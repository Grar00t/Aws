import Link from 'next/link';
import { Brain, BarChart3, ShieldCheck, Settings, Wallet } from 'lucide-react';

export function Sidebar() {
  const items = [
    { href: '/dashboard', label: 'لوحة التحكم', icon: <BarChart3 size={18}/> },
    { href: '/ai', label: 'نماذج الذكاء', icon: <Brain size={18}/> },
    { href: '/billing', label: 'الفوترة', icon: <Wallet size={18}/> },
    { href: '/security', label: 'الأمن والامتثال', icon: <ShieldCheck size={18}/> },
    { href: '/settings', label: 'الإعدادات', icon: <Settings size={18}/> }
  ];
  return (
    <aside className="h-screen bg-slate-950 border-l border-white/10 p-4">
      <div className="text-lg font-semibold mb-6">GrA × Genius</div>
      <nav className="space-y-2">
        {items.map((it)=> (
          <Link key={it.href} href={it.href} className="flex items-center gap-2 p-2 rounded hover:bg-white/5">
            <span>{it.icon}</span><span>{it.label}</span>
          </Link>
        ))}
      </nav>
    </aside>
  );
}
