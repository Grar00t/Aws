'use client';
import { ThemeSwitcher } from './ThemeSwitcher';
import { LangToggle } from './LangToggle';

export function Topbar() {
  return (
    <header className="sticky top-0 z-10 bg-slate-950/70 backdrop-blur border-b border-white/10">
      <div className="container-slim h-14 flex items-center justify-between">
        <div className="text-sm opacity-70">منصة ذكاء سيادي • Bluvalt • PDPL</div>
        <div className="flex items-center gap-3">
          <LangToggle />
          <ThemeSwitcher />
        </div>
      </div>
    </header>
  );
}
