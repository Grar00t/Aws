import type { Config } from 'tailwindcss'
const config: Config = {
  darkMode: ['class'],
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#004B91',
        accent: '#CBA135',
        surface: '#0F172A'
      }
    }
  },
  plugins: [require('tailwindcss-rtl')]
}
export default config
